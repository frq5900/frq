<?php 
include 'header.php'
?>
<html>
<head>
</head>
<body><center>
<form method="POST" action="../employee/reg.php">
<input type="submit" name="submit" value="Add Employee">
</form>
<form method="POST" action="adminhome.php">
<input type="submit" name="submit" value="Employee Details">
</form>
</center>
</body>
</html>
<?php 
include 'footer.php'
?>