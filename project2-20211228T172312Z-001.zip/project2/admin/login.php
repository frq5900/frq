<?php include 'header.php'?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Admin Login</title>
</head>

<body> <font face="comic sans ms">
	<h3>Admin Login</h3>
	<form action="login_action.php" method="post"><table>
		<tr>
			<td>Username :</td>
			<td><input type="text" name="username" placeholder="username"><br></td>
		</tr>
		<tr>
			<td>Password :</td>
			<td><input type="password" name="password" placeholder="password"></td>
		</tr>
		</table>
			<input type="submit" value="Submit" name="submit">
		
	</form>
</font>
</body>

</html>


<?php include 'footer.php'?>