 <font face="comic sans ms"><center>
<table>
<tr><h4>Admin Details</h4></tr>
<tr><th>ID</th><th>NAME</th><th>AGE</th>
<th>CONTACT</th><th>E-Mail</th></tr>
<?php
include 'dbconnect.php';
$s="select * from admin";
$s1=mysqli_query($con,$s);
 while($s2=mysqli_fetch_assoc($s1))
       {
           $id=$s2['id'];
           $nm=$s2['name'];
           $ag=$s2['age'];
           $cc=$s2['contact'];
           $em=$s2['email'];		
       ?>
<tr><td><?php echo $id?></td><td><?php echo $nm?></td>
<td><?php echo $ag?></td><td><?php echo $cc?></td>
<td><?php echo $em?></td></tr>
<?php
}
?>
</table>
</center>