
<?php
session_start();
include 'dbconnect.php'; 
   
	$name=$_POST['name'];
	$age=$_POST['age'];
	$email=$_POST['email'];
	$contact=$_POST['contact'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	$_SESSION['username']=$username;
		$s="select username from login where username='$username'";
		$s1= mysqli_query($con,$s);
		$numrows=mysqli_num_rows($s1);
      if($numrows==0)
      {
        $sql1="INSERT INTO admin(name,age,contact,email)
                     values('$name','$age','$contact','$email')";
					
       $result=mysqli_query($con,$sql1);
       $sql2="INSERT INTO login(username,password,type)
                    values('$username','$password','1')";
      $result1=mysqli_query($con,$sql2);

       if($result==TRUE)
        {
          echo "<script>
          alert('registration success');
          window.location='login.php'; 
          </script> ";
        }
       else
       {
         echo"<script>alert('not registered');
        window.location='reg.php';</script>";
      }
      }
      else
      {
       echo"<script>alert('username already exist');
       window.location='reg.php';</script>";
      }
      ?>

