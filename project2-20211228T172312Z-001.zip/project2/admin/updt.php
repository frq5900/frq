<?php 
include 'header.php'
?>
<?php

if(isset($_POST["updt"]))

{
include ("dbconnect.php");
$id=$_POST["idu"];
$s="select * from employee where id='$id'";
$s1=mysqli_query($con,$s);
 while($s2=mysqli_fetch_assoc($s1))
       {
           
           
?>
<html>
<body>
<h3>Update Employee Details</h3>
<center>
<form  method="POST" action="#">
<table>
<tr>
<td>ID</td><td><input type="text" name="id" value="<?php echo $id?> " required readonly="readonly"></td>
</tr>
<tr>
<td>Name</td><td><input type="text" name="nm" value="<?php echo $s2['name']?> " required></td>
</tr>
<tr>
<td>Age</td><td><input type="text" name="ag" value="<?php echo $s2['age']?> " required></td>
</tr>
<tr>
<td>Qualification</td><td><input type="text" name="ql" value="<?php echo $s2['qualification']?> " required"></td>
</tr>
<tr>
<td>Contact</td><td><input type="text" name="cc" value="<?php echo $s2['contact']?> " required"></td>
</tr>
<tr>
<td>Status</td><td><input type="text" name="st" value="<?php echo $s2['status']?> " required"></td>
</tr>
</table>
<?php
 }
?>
<input type="submit" name="updt2" value="Update">
</form>
</center>
</body>
</html>

<?php 
include 'header.php'
?>

<?php
if(isset($_POST["updt2"]))
{
         
         $nm=$_POST["nm"];
         $ag=$_POST["ag"];
         $ql=$_POST["ql"];
         $cc=$_POST["cc"];
         $st=$_POST["st"];
       	
 
$query="UPDATE `employee` SET `name`='$nm',`age`='$ag',`qualification`='$ql',`contact`='$cc',`status`='$st' WHERE `id`='$id'";
//echo $query; echo $id;
mysqli_query($con,$query);
echo "<script>alert('Updated Successfully')</script>";
echo "<META http-equiv='refresh' content='1;adminhome.php'>";
}

?> 



 
