<?php 
include 'header.php' 
?>
<html>
<head><title>Forms</title></head>
<body>
<h3>Admin Register!</h3>
<font face="comic sans ms">
<form action="reg_action.php" method="POST">
<table>
<tr>
<td>Name : </td><td><input type="text" name="name" required=" " pattern="[a-zA-Z\s]+"></td>
</tr>
<tr>
<td>Age : </td><td><input type="text" name="age" required=" " pattern="[0-9]{2}"></td>
</tr>

<tr>
<td>Contact : </td><td><input type="text" name="contact" required=" " pattern="[987]{1,1}[0-9]{9,9}"></td>
</tr>
<tr>
<td>Email : </td><td><input type="text" name="email" required=" "></td>
</tr>
<tr>
<td>Username :</td>
<td><input type="text" name="username"></td>
</tr>
<tr>
<td>Password :</td>
<td><input type="password" name="password"></td>
</tr>
</table>
<br>
<input type="submit" name="submit" value="Submit">

</form>
</font>
</body>
</html>
<?php 
include 'footer.php'
?>