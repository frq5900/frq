<?php
	session_start();
	include 'dbconnect.php';
	$username=$_POST['username'];
	$password=$_POST['password'];
	$_SESSION['username']=$username;
	$sql="SELECT * FROM login WHERE username='$username' AND password='$password'";
	$result=mysqli_query($con,$sql);
	if($data=mysqli_fetch_assoc($result)) {
		$type=$data['type'];
		$memid=$data['id'];
		$_SESSION['id']=$id;
		if($type==1) {
			echo "<script>
						alert('Login Successful');
						window.location='adminhome.php';
				</script>";
		}
		else if ($type==0) {
			echo "<script>
						alert('Login Successful');
						window.location='userhome.php';
				</script>";
		}
		else if($type==2) {
			echo "<script>
						alert('Login Successful');
						window.location='staffhome.php';
				</script>";
		}
		else
			echo "<script>
					alert('Invalid username & password');
					window.location='login.php';
				</script>";
	}
?>
