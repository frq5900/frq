<?php 
include 'header.php'
?>
<html>
<body>
<form  method="POST" action="updt.php">
<center>
<h3>Welcome to E-Grocs</h3>
<h5>let's make a better world</h5>
<center>
<table>
<tr><h4>Employee Details</h4></tr>
<tr><th>ID</th><th>NAME</th><th>AGE</th>
<th>Qualification</th><th>Contact</th><th>Status</th></tr>
<?php
include 'dbconnect.php';
$s="select * from employee";
$s1=mysqli_query($con,$s);
 while($s2=mysqli_fetch_assoc($s1))
       {
           $id=$s2['id'];
           $nm=$s2['name'];
           $ag=$s2['age'];
           $ql=$s2['qualification'];
           $cc=$s2['contact'];
           $st=$s2['status'];		
       ?>
<tr><td><input type="text" name="id" value="<?php echo $id?> " required readonly="readonly"></td>
<td><input type="text" name="nm" value="<?php echo $nm?>" required readonly="readonly"></td>
<td><input type="text" name="ag" value="<?php echo $ag?>" required readonly="readonly"></td>
<td><input type="text" name="ql" value="<?php echo $ql?>" required readonly="readonly"></td>
<td><input type="text" name="cc" value="<?php echo $cc?>" required readonly="readonly"></td>
<td><input type="text" name="st" value="<?php echo $st?>" required readonly="readonly"></td>
</tr>
<?php
}
?>
</table>

</center>
<br><br><br>
<input type="text" name="idu" placeholder="Enter id" required>&nbsp;&nbsp;&nbsp;
<input type="submit" name="updt" value="Update" required>&nbsp;&nbsp;&nbsp;
<input type="submit" name="dlt" value="Delete" required>
</form>
</body>
</html>
<?php
include 'footer.php'
?>
