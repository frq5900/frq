<?php include 'header.php'?>
<html>
<body>
<center>
<h3>Welcome to E-Grocs</h3>
<h5>lets shop some</h5>
</center>
</body>
</html>
<?php include 'footer.php'?>