<?php
if(isset($_POST["updt"]))

{
include ("dbconnect.php");
$id=$_POST["id"];
$nm=$_POST["nm"];
$ag=$_POST["ag"];
$ql=$_POST["ql"];
$cc=$_POST["cc"];
$st=$_POST["st"];

	$query="UPDATE `employee` SET `name`=[$nm],`age`=[$ag],`qualification`=[$ql],`contact`=[$cc],`status`=[$st] WHERE `id`=[$id]";
	echo $query;
	mysqli_query($con,$query);
	echo "<script>alert('Updated Successfully')</script>";
	<!--echo "<META http-equiv='refresh' content='1;adminhome.php'>";-->
}
 



 

?>