<?php
$con=mysqli_connect("localhost","root","","egroc");
?>



