<?php include 'header.php'?>
<html>
<head>
</head>
<body>
<h3>Welcome to E-Grocs</h3>
<h5>Adios Amigo</h5>
<center>
<table>
<tr><h4>Customer Details</h4></tr>
<tr><th>ID</th><th>NAME</th><th>AGE</th><th>Contact</th><th>Email</th>
<th>Location</th><th>Pincode</th><th>Status</th></tr>
<?php
include 'dbconnect.php';
$s="select * from customer";
$s1=mysqli_query($con,$s);
 while($s2=mysqli_fetch_assoc($s1))
       {
           $id=$s2['id'];
           $nm=$s2['name'];
           $ag=$s2['age'];
           $cc=$s2['contact'];
           $em=$s2['email'];
           $lc=$s2['location'];
           $pc=$s2['pincode'];           
           $st=$s2['status'];		
       ?>
<tr><td><?php echo $id?></td><td><?php echo $nm?></td>
<td><?php echo $ag?></td><td><?php echo $cc?></td><td><?php echo $em?></td>
<td><?php echo $lc?></td><td><?php echo $pc?></td><td><?php echo $st?></td></tr>
<?php
}
?>
</table>
</center>

</body>
</html>
<?php include 'footer.php'?>