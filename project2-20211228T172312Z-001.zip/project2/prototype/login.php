

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Login</title>
</head>

<body>
	<form action="login_action.php" method="post">
		<div>
			<span>Username</span>
			<input type="text" name="username" placeholder="enter username">
		</div>
		<div>
			<span>Password</span>
			<input type="password" name="password" placeholder="enter password">
		</div>
		<div>
			<input type="submit" value="Submit" name="submit">
		</div>
	</form>
</body>

</html>


