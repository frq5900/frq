<?php
    include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Register</title>
</head>

<body>

	<form action="reg_action.php" method="post">
		<div>
			<span>ID</span>
			<input type="text" name="id">
		</div>
		<div>
			<span>Name</span>
			<input type="text" name="name" required="">
		</div>
		<div>
			<span>Age</span>
			<input type="text" name="age" pattern="[0-9]{2}">
		</div>
		<div>
			<span>Qualification</span>
			<input type="text" name="qualification" required="" pattern="[a-zA-z\s]+">
		</div>
		<div>
			<sapn>Contact Number</sapn>
			<input type="text" name="contactno" required="" pattern="[987]{1,1}{0,9}{9,9}">
		</div>
		<div>
			<span>Username</span>
			<input type="text" name="username">
		</div>
		<div>
			<span>Password</span>
			<input type="password" name="password">
		</div>
		<div>
			<input type="submit" value="Submit">
		</div>
	</form>

</body>

</html>
<?php
    include 'footer.php';
?>
