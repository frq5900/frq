<?php 
    session_start();
    include 'dbconnect.php';
	$id=$_POST['id'];
    $name=$_POST['name'];
    $age=$_POST['age'];
    $qualification=$_POST['qualification'];
    $contactno=$_POST['contactno'];
    $username=$_POST['username'];
    $password=$_POST['password'];
    $_SESSION['username']=$username;
    $s="SELECT USERNAME FROM login WHERE username='$username'";
    $s1=mysqli_query($con,$s);
    $numrows=mysqli_num_rows($s1);
    if($numrows==0) {
        $sql1="INSERT INTO member(id,name,age,qualification,contactno,status) VALUES ('$id','$name','$age','$qualification','$contactno','0')";
        $result=mysqli_query($con,$sql1);
        $sql2="INSERT INTO signup(id,username,password,type) VALUES ('$id','$username','$password','0')";
        $result1=mysqli_query($con,$sql2);
        if($result==true) {
            echo "<script>
                    window.location='userhome.php';
                    alert('Registration Success');
                </script>";
        }
        else {
            echo "<script>
                    alert('Not Registered');
                    window.location='reg.php';
                </script>";
        }
    }
    else {
        echo "<script>
                alert('Username already exist');
                window.loaction='reg.php';
            </script>";
    }
?>
