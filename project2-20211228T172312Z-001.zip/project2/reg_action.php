
<?php
session_start();
include 'dbconnect.php'; 
   
	$name=$_POST['name'];
	$age=$_POST['age'];
	$contact=$_POST['contact'];
               $email=$_POST['email'];
	$location=$_POST['location'];
	$pincode=$_POST['pincode'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	$_SESSION['username']=$username;
		$s="select username from login where username='$username'";
		$s1= mysqli_query($con,$s);
		$numrows=mysqli_num_rows($s1);
      if($numrows==0)
      {
        $sql1="INSERT INTO customer(name,age,contact,email,location,pincode,status)
                     VALUES('$name','$age','$contact','$email','$location','$pincode','0')";
					
       $result=mysqli_query($con,$sql1);
	
       $sql2="INSERT INTO login(username,password,type)
                    values('$username','$password','0')";
      $result1=mysqli_query($con,$sql2);
	echo $sql1;
       if($result==TRUE)
        {
          echo "<script>
          alert('registration success');
          window.location= 'login.php';
          </script> ";
        }
       else
       {
         echo"<script>alert('not registered');
        window.location='reg.php';</script>";
      }
      }
      else
      {
       echo"<script>alert('username already exist');
       window.location='reg.php';</script>";
      }
      ?>

